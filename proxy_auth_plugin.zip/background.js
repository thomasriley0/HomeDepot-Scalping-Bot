
          var config = {
                  mode: "fixed_servers",
                  rules: {
                  singleProxy: {
                      scheme: "http",
                      host: "155.254.220.209",
                      port: parseInt(63680)
                  },
                  bypassList: ["localhost"]
                  }
              };

          chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

          function callbackFn(details) {
              return {
                  authCredentials: {
                      username: "leaf",
                      password: "Hze5HN7B"
                  }
              };
          }

          chrome.webRequest.onAuthRequired.addListener(
                      callbackFn,
                      {urls: ["<all_urls>"]},
                      ['blocking']
          );
          